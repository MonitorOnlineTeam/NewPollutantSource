export default {
  isShowBreadcrumb: true, // 是否显示面包屑
  middlePageOpenMode: 'single', // 'single' or 'tabs'
}
