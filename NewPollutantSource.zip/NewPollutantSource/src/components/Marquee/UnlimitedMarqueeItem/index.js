import UnlimitedMarqueeItem from './UnlimitedMarqueeItem';

export default UnlimitedMarqueeItem;
