import UnlimitedMarquee from './UnlimitedMarquee';

export default UnlimitedMarquee;
