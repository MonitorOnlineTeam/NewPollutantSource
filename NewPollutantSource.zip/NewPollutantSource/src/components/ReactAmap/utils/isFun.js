const isFun = (arg) => {
  return !!arg && (typeof arg === 'function');
};

export default isFun;
