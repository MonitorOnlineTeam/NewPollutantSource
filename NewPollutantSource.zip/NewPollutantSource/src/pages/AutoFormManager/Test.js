import React, { PureComponent } from 'react';

class Test extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {  };
  }
  render() {
    return (
      111
    );
  }
}

export default Test;